## Context

The application uses MUI components across various pages and forms. Currently, these components rely on MUI's default theme. To establish a cohesive brand identity with the warm orange primary color (#fe9a00), we need to create a custom theme configuration and integrate it globally.

## Goals / Non-Goals

**Goals:**
- Create a custom MUI theme configuration object with #fe9a00 as the primary color.
- Set up a theme module that exports the theme configuration.
- Integrate the custom theme globally through a ThemeProvider wrapper in the root layout.
- Ensure all components automatically inherit the custom primary color and related palette.
- Support theme extensibility for future customizations (secondary colors, typography, component overrides).

**Non-Goals:**
- Creating theme variants or dark mode support (can be added later).
- Building a theme customization UI.
- Migrating to a different styling library.
- Changing component APIs or structure.

## Decisions

1. Create a centralized theme module (`lib/theme/index.ts`) that exports the MUI theme configuration.
   - Rationale: Keeps theme configuration in one place for easier maintenance and updates.
   - Alternative considered: inline theme in layout. Rejected for maintainability.

2. Use MUI's `createTheme()` utility to generate the theme object.
   - Rationale: Official MUI pattern; provides type safety and access to all theme features.
   - Alternative considered: plain object configuration. Rejected to leverage MUI utilities.

3. Apply the theme globally via ThemeProvider in the root layout component.
   - Rationale: Ensures all nested components can access and use the custom theme.
   - Alternative considered: wrapping specific pages. Rejected for global consistency.

4. Set #fe9a00 as the primary color in the palette configuration.
   - Rationale: MUI's primary color is used by default for interactive elements (buttons, links, form accents).
   - Alternative considered: using secondary or custom colors. Rejected to maximize visual impact.

## Risks / Trade-offs

- [Risk] Theme changes could affect existing form layouts if components depend on default colors. → Mitigation: test all existing pages and components after theme application.
- [Risk] Brand guidelines may evolve requiring future theme updates. → Mitigation: document theme structure for easy adjustments.
- [Risk] Users with accessibility concerns may need additional contrast. → Mitigation: ensure sufficient WCAG contrast ratios for text on primary backgrounds.
