## 1. Jest Infrastructure Setup

- [x] 1.1 Install Jest dev dependencies: `jest`, `jest-environment-jsdom`, `@testing-library/react`, `@testing-library/jest-dom`, `@testing-library/user-event`, `@types/jest`.
- [x] 1.2 Create `jest.config.ts` at project root using `next/jest` `createJestConfig` with jsdom environment and `jest.setup.ts` as setup file.
- [x] 1.3 Create `jest.setup.ts` at project root importing `@testing-library/jest-dom`.
- [x] 1.4 Add `"test": "jest --passWithNoTests"` and `"test:watch": "jest --watch"` scripts to `package.json`.
- [x] 1.5 Create shared test utility `test-utils/renderWithProviders.tsx` wrapping renders in MUI `ThemeProvider`, `LocalizationProvider` (dayjs), and RHF `FormProvider`.

## 2. Unit Tests – Form Field Components

- [x] 2.1 Write tests for `TextInputField`: renders label, renders value, renders helper text, renders error state.
- [x] 2.2 Write tests for `TextareaField`: renders label, renders multiline input, renders error state.
- [x] 2.3 Write tests for `SelectField`: renders label, renders options, selects an option, renders error state.
- [x] 2.4 Write tests for `CheckboxField`: renders label, toggles checked state, renders in disabled state.
- [x] 2.5 Write tests for `SwitchField`: renders label, toggles switch state, renders in disabled state.
- [x] 2.6 Write tests for `RadioGroupField`: renders options, selects an option, renders error state.
- [x] 2.7 Write tests for `AutocompleteField`: renders input, filters options on type, selects an option, renders error state.
- [x] 2.8 Write tests for `DateTimeField`: renders label, renders date picker, renders error state.

## 3. Unit Tests – RHF Wrapper Components

- [x] 3.1 Write tests for `RHFTextInput`: integrates with RHF `useForm`, shows validation error on submit.
- [x] 3.2 Write tests for `RHFTextarea`: integrates with RHF `useForm`, shows validation error on submit.
- [x] 3.3 Write tests for `RHFSelect`: integrates with RHF `useForm`, updates field value on selection change.
- [x] 3.4 Write tests for `RHFCheckbox`: integrates with RHF `useForm`, toggles field value.
- [x] 3.5 Write tests for `RHFSwitch`: integrates with RHF `useForm`, toggles field value.
- [x] 3.6 Write tests for `RHFRadioGroup`: integrates with RHF `useForm`, updates field value on selection.
- [x] 3.7 Write tests for `RHFAutocomplete`: integrates with RHF `useForm`, updates field value on option select.
- [x] 3.8 Write tests for `RHFDateTime`: integrates with RHF `useForm`, renders date picker within form context.

## 4. Unit Tests – Validation Schemas

- [x] 4.1 Write tests for schemas in `lib/validation/schemas.ts`: verify valid data passes, invalid data returns expected error messages, boundary cases (empty string, null, whitespace).

## 5. Unit Tests – Theme

- [x] 5.1 Write tests for `lib/theme/index.ts`: verify theme export is a valid MUI theme object, verify primary/secondary palette values, verify typography settings.

## 6. Verification

- [x] 6.1 Run `npm test` and confirm all tests pass with no errors.
- [x] 6.2 Fix any type errors or configuration issues surfaced during the test run.
