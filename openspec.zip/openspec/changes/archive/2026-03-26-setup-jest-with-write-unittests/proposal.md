## Why

The project has no automated testing infrastructure. As the codebase grows with MUI form field components, React Hook Form wrappers, Zod validation schemas, and custom theming, there is no way to verify that components behave correctly or catch regressions introduced by changes. Establishing Jest as the unit testing framework with React Testing Library will provide a repeatable, fast feedback loop for verifying component behavior, validation logic, and utility correctness.

## What Changes

- Install and configure Jest with `next/jest` transformer for Next.js 16 / React 19 compatibility.
- Add React Testing Library (`@testing-library/react`, `@testing-library/jest-dom`, `@testing-library/user-event`) for component testing.
- Add a `jest.config.ts` and supporting setup file (`jest.setup.ts`) to the project root.
- Add a `test` script to `package.json`.
- Write unit tests covering the core form field components, RHF wrapper components, Zod validation schemas, and the MUI theme configuration.

## Capabilities

### New Capabilities
- `jest-nextjs-setup`: A working Jest + React Testing Library configuration that supports TypeScript, CSS modules, Next.js internals, and jsdom rendering.
- `unit-tests-form-fields`: Unit tests for all MUI-based form field components (`TextInputField`, `SelectField`, `CheckboxField`, `SwitchField`, `RadioGroupField`, `TextareaField`, `AutocompleteField`, `DateTimeField`).
- `unit-tests-rhf-wrappers`: Unit tests for React Hook Form wrapper components (`RHFTextInput`, `RHFSelect`, `RHFCheckbox`, `RHFSwitch`, `RHFRadioGroup`, `RHFTextarea`, `RHFAutocomplete`, `RHFDateTime`).
- `unit-tests-validation`: Unit tests for Zod validation schemas defined in `lib/validation/schemas.ts`.
- `unit-tests-theme`: Unit tests verifying the MUI theme configuration exports from `lib/theme/`.

### Modified Capabilities
- None. Test infrastructure is additive; no production source files are changed.

## Impact

- Affected code: `package.json` (new dev dependencies and test script), new config files at project root, new `__tests__/` directories alongside source.
- APIs: none changed.
- Dependencies: adds `jest`, `jest-environment-jsdom`, `@testing-library/react`, `@testing-library/jest-dom`, `@testing-library/user-event`, `@types/jest`, and `ts-jest` (or `@swc/jest` via `next/jest`).
- Systems: local developer workflow and CI pipeline gain a `pnpm test` / `npm test` step.
