## Context

The project is a Next.js 16.2.1 application using React 19, TypeScript, MUI v7, React Hook Form v7, Zod v4, and the Next.js App Router. It has no existing test infrastructure. Jest is the standard test runner for Next.js projects; Next.js ships a `next/jest` export that provides a `createJestConfig` helper pre-configured for SWC transpilation, CSS/image mocking, and compatibility with the App Router. React Testing Library is the standard companion for rendering and interacting with React components in jsdom.

## Goals / Non-Goals

**Goals:**
- Install Jest and React Testing Library with full TypeScript support.
- Configure `jest.config.ts` using `next/jest`'s `createJestConfig` so tests run correctly with the App Router, SWC, path aliases, and CSS/asset mocks.
- Create `jest.setup.ts` to import `@testing-library/jest-dom` matchers globally.
- Add `"test": "jest --passWithNoTests"` and `"test:watch": "jest --watch"` scripts to `package.json`.
- Write unit tests for all eight form field components, all eight RHF wrapper components, Zod validation schemas, and the MUI theme.

**Non-Goals:**
- End-to-end or integration testing (no Playwright/Cypress).
- Testing Next.js server components or API routes.
- Code coverage enforcement or CI pipeline changes.
- Snapshot testing (prefer behavioral assertions).

## Decisions

1. **Use `next/jest` (`createJestConfig`) instead of bare `jest` + `babel-jest`.**
   - Rationale: Official Next.js recommendation; handles SWC transforms, module name mapping from `tsconfig.json` paths, and CSS/image mocking automatically. Works with Next.js 16 and React 19.
   - Alternative considered: `ts-jest`. Rejected — slower compilation; `next/jest` via SWC is faster and requires less configuration.

2. **Use `jest-environment-jsdom` as the test environment.**
   - Rationale: Components render DOM; jsdom simulates browser APIs without a real browser.
   - Alternative considered: `node` environment. Rejected — React Testing Library requires DOM.

3. **Place test files in `__tests__/` directories co-located alongside source, mirroring the source tree.**
   - Example: `components/forms/fields/__tests__/TextInputField.test.tsx`
   - Rationale: Easy to locate tests; consistent with Next.js conventions.
   - Alternative considered: top-level `tests/` folder. Rejected — harder to maintain as codebase grows.

4. **Use `@testing-library/user-event` for simulating user interaction instead of `fireEvent`.**
   - Rationale: `userEvent` more faithfully replicates real browser events (pointer, keyboard, composition).
   - Alternative considered: `fireEvent` only. Rejected — produces less realistic tests.

5. **Wrap components under test in required MUI `ThemeProvider` and RHF `FormProvider` via a shared `renderWithProviders` utility.**
   - Rationale: MUI components require a theme context; RHF wrappers require a `FormProvider`. A shared render helper avoids repetition.
   - Alternative considered: no wrapper utility; inline per test. Rejected — too verbose and inconsistent.

## Risks / Trade-offs

- [Risk] MUI v7 with Emotion may produce warnings in jsdom about `insertRule` CSS-in-JS. → Mitigation: mock or suppress CSS insertion warnings in `jest.setup.ts`.
- [Risk] `@mui/x-date-pickers` `DateTimeField` tests require a date adapter context (`LocalizationProvider`). → Mitigation: include `LocalizationProvider` (dayjs adapter) in the `renderWithProviders` utility.
- [Risk] React 19's concurrent features may cause test flakiness with async state updates. → Mitigation: use `act` wrappers from `@testing-library/react` (auto-wrapped in render helpers); use `waitFor` for async assertions.
- [Risk] `next/jest` version coupling — `createJestConfig` API could change between Next.js minor releases. → Mitigation: pin dev dependency versions; document upgrade path in `README`.
