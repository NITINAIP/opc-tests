## Why

The application's current custom MUI theme uses the #fe9a00 orange primary color but lacks alignment with Fluent UI design principles. Fluent UI is Microsoft's modern design system emphasizing clarity, subtle depth, accessible color palettes, and refined typography. Styling the MUI theme to follow Fluent UI principles will improve visual consistency with modern design standards, enhance accessibility, provide better component spacing and interactions, and create a more polished and professional appearance while maintaining the existing brand color.

## What Changes

- Update the MUI theme palette to use Fluent UI-inspired color palette (subtle neutrals, better contrast ratios, improved accessibility).
- Apply Fluent UI typography system (Segoe UI font family, refined font weights and sizes, consistent line heights).
- Configure component styles following Fluent UI design principles (subtle shadows, refined spacing, accessible focus states).
- Update the root layout and theme integration to support Fluent UI styling.
- Ensure form components and interactive elements reflect Fluent UI design language.

## Capabilities

### New Capabilities
- `fluent-inspired-theme`: Transform the existing MUI theme to follow Fluent UI design principles while maintaining the #fe9a00 primary brand color, including updated palette, typography, spacing, and component styles.

### Modified Capabilities
- `custom-mui-theme`: Enhanced with Fluent UI design principles and improved accessibility.

## Impact

- Affected code: MUI theme configuration (`lib/theme/index.ts`), global layout, all pages and components using MUI.
- APIs: theme structure remains compatible, no breaking changes to component integration.
- Dependencies: no new dependencies required (MUI already provides all needed features).
- Systems: visual presentation, component styling, and interaction design across the entire application.
