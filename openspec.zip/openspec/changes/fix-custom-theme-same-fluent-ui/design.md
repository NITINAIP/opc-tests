## Context

The application already has a custom MUI theme with the #fe9a00 primary color. However, this theme doesn't fully embrace Fluent UI design principles. Fluent UI is a mature, accessible design system developed by Microsoft that emphasizes clarity, accessible color relationships, refined spacing, and a modern aesthetic. Aligning the MUI theme with Fluent UI will provide a more cohesive, professional, and accessible visual experience.

## Goals / Non-Goals

**Goals:**
- Adopt Fluent UI color palette principles: neutral backgrounds, accent colors with proper contrast, semantic colors (error, warning, success).
- Implement Fluent UI typography: Segoe UI font stack, refined font weights, consistent line heights, proper vertical rhythm.
- Apply Fluent UI spacing and layout principles: consistent padding/margins, clear visual hierarchy, subtle depth through shadows.
- Update component styling to match Fluent UI interaction patterns: subtle focus indicators, smooth transitions, accessible state indicators.
- Maintain the #fe9a00 brand color as the primary accent color while supporting Fluent UI's color accessibility requirements.
- Keep the existing MUI component integration unchanged (no breaking API changes).

**Non-Goals:**
- Adding new dependencies or switching to a different UI library.
- Creating a complete Fluent UI implementation (some components may not fully match Fluent UI; focus on theme principles).
- Changing the app's functional behavior or component structure.
- Creating Fluent UI-specific components (enhance MUI theme only).

## Decisions

1. Update the existing `lib/theme/index.ts` rather than creating a new theme file.
   - Rationale: Maintains backward compatibility, single source of truth.
   - Alternative considered: separate theme file. Rejected to avoid confusion.

2. Use Segoe UI as the primary font family (Fluent UI standard).
   - Rationale: Fluent UI's design system is built around Segoe UI; provides authenticity and visual cohesion.
   - Alternative considered: keeping Roboto. Rejected to properly align with Fluent UI.

3. Implement Fluent UI's neutral color palette (grays) for backgrounds and borders.
   - Rationale: Fluent UI uses carefully balanced neutral tones; provides sophistication and accessibility.
   - Alternative considered: minimal changes to palette. Rejected to properly adopt Fluent UI principles.

4. Ensure all changes maintain WCAG AAA contrast ratios where possible.
   - Rationale: Fluent UI emphasizes accessibility; maintains app's commit to accessibility.
   - Alternative considered: WCAG AA only. Rejected for higher accessibility standards.

## Risks / Trade-offs

- [Risk] Font change from Roboto to Segoe UI may affect users without the font installed. → Mitigation: provide fallback font stack (Segoe UI → more monospace/serif alternatives).
- [Risk] Designers familiar with the original theme may need adjustment time. → Mitigation: provide clear migration documentation.
- [Risk] Some Fluent UI patterns may not map perfectly to MUI components. → Mitigation: document deviations and stay true to MUI's strengths.
- [Trade-off] Fluent UI's extensive color palette vs. maintaining simplicity. → Solution: use core Fluent UI colors with clear intent mapping.
