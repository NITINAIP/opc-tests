# Fluent UI-Inspired MUI Theme Specification

## Overview

This specification defines the enhanced MUI theme aligned with Fluent UI design principles, maintaining the #fe9a00 primary brand color while adopting Fluent UI's color palette, typography, spacing, and component styling approach.

## Design Principles

### Clarity
- Clear visual hierarchy through typography and spacing
- Distinct interaction states (hover, focus, active, disabled)
- Legible text with proper contrast ratios (WCAG AAA)

### Depth & Appearance
- Subtle shadows for elevation (Fluent's `shadow-depth-*` concept)
- Refined spacing based on 4px grid system
- Consistent visual weight and balance

### Accessibility
- All colors maintain high contrast ratios
- Focus indicators are prominent and visible
- Motion is respectful (reduced motion support)
- Semantic color usage (error, warning, success)

## Color Palette

### Accent Color (Brand)
- **Primary:** #fe9a00 (warm orange, maintained from brand)
- **Primary Light:** #ffb84d
- **Primary Dark:** #cc7700

### Neutral Palette (Fluent UI inspired)
| Intent | Color | Usage |
|--------|-------|-------|
| **Surface** | #ffffff | Primary backgrounds |
| **Surface Alt** | #f5f5f5 | Secondary backgrounds |
| **Subtle** | #e0e0e0 | Borders, dividers |
| **Secondary** | #757575 | Secondary text, icons |
| **Tertiary** | #616161 | Tertiary text |
| **Primary Text** | #333333 | Body text, headings |

### Semantic Colors
| Intent | Color | Usage |
|--------|-------|-------|
| **Error** | #c4373e | Errors, destructive actions |
| **Warning** | #ff8c00 | Warnings, caution |
| **Success** | #107c10 | Success, confirmations |
| **Info** | #0078d4 | Information, hints |

## Typography System

### Font Family Stack
```
"Segoe UI", "Helvetica Neue", sans-serif
```

### Heading Styles
- **H1:** 32px, weight 600, line-height 1.25
- **H2:** 28px, weight 600, line-height 1.29
- **H3:** 24px, weight 600, line-height 1.33
- **H4:** 20px, weight 600, line-height 1.4
- **H5:** 16px, weight 600, line-height 1.5
- **H6:** 14px, weight 600, line-height 1.43

### Body Styles
- **Body (Large):** 16px, weight 400, line-height 1.5
- **Body (Regular):** 14px, weight 400, line-height 1.43
- **Body (Small):** 12px, weight 400, line-height 1.42
- **Caption:** 12px, weight 400, line-height 1.33

### Semantic Weights
- **Regular:** 400 (body text)
- **Semibold:** 600 (emphasis, headings)
- **Bold:** 700 (strong emphasis)

## Component Styling

### Spacing System (4px grid)
- **XS:** 4px
- **SM:** 8px
- **MD:** 12px
- **LG:** 16px
- **XL:** 24px
- **2XL:** 32px

### Button
- **Padding:** 8px (vertical) × 16px (horizontal) for default
- **Focus Ring:** 2px outline, visible against background
- **Hover Transform:** Subtle background color shift
- **Transition:** 150ms ease cubic-bezier

### Text Input / TextField
- **Border:** 1px solid #e0e0e0 (Subtle color)
- **Focus Border:** 2px solid #fe9a00 (Primary color)
- **Background:** #ffffff (Surface)
- **Focus Ring:** 2px primary color outline
- **Padding:** 8px 12px

### Surfaces (Card, Container)
- **Background:** #ffffff (Surface) or #f5f5f5 (Surface Alt)
- **Border:** 1px solid #e0e0e0 (Subtle)
- **Shadow:** `0 1px 3px rgba(0,0,0,0.08)` (subtle elevation)
- **Padding:** 16px (LG spacing)
- **Border Radius:** 4px (subtle, Fluent-inspired)

### Focus Indicator
- **Color:** #fe9a00 (Primary)
- **Width:** 2px outline
- **Offset:** 2px from element
- **Style:** Always visible, never hidden

## Accessibility Requirements

### Contrast Ratios
- Text on primary color: 4.5:1 minimum (AA), 7:1 recommended (AAA)
- All semantic colors maintain 4.5:1+ contrast with text
- Focus indicators have 3:1 minimum contrast with surroundings

### Motion
- Respect `prefers-reduced-motion` CSS media query
- Default transitions: 150ms ease
- Reduced motion: 0ms (instant)

### Keyboard Navigation
- All interactive elements focusable via Tab key
- Focus order logical and predictable
- Focus indicator always visible

## Integration

The theme is applied in `app/layout.tsx` via `ThemeProvider`:

```typescript
import { ThemeProvider } from '@mui/material/styles';
import theme from '@/lib/theme';

export default function RootLayout({ children }) {
  return (
    <ThemeProvider theme={theme}>
      {children}
    </ThemeProvider>
  );
}
```

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Requires CSS custom properties support (CSS variables not essential for core functionality)

## Resources

- [Fluent UI Design Principles](https://developer.microsoft.com/en-us/fluent/)
- [Fluent UI Web Components](https://learn.microsoft.com/en-us/windows/apps/design/)
- [MUI Theming Documentation](https://mui.com/material-ui/customization/theming/)
- [WCAG 2.1 Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)
