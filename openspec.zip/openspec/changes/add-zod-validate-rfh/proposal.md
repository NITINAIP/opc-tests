## Why

Forms currently use React Hook Form with manual validation logic or basic constraint checks, but lack a standardized schema-based validation approach. Integrating Zod with React Hook Form will provide a type-safe, reusable validation layer that catches errors at the schema level and eliminates boilerplate validation code across all form pages.

## What Changes

- Add Zod as a schema validation library and integrate it with React Hook Form via resolver pattern.
- Provide utilities/helpers to create Zod schemas and automatically wire them to RHF forms.
- Standardize validation error mapping from Zod schema errors to RHF field state.
- Enable reusable, shareable form schemas across pages with automatic type inference.

## Capabilities

### New Capabilities
- `zod-rhf-validation`: Provide Zod schema definition and React Hook Form resolver integration for type-safe form validation with automatic error handling.

### Modified Capabilities
- None.

## Impact

- Affected code: form pages, validation utilities, form hook layers.
- APIs: introduces schema-based validation contract for forms; changes form error type contract from strings to Zod validation messages.
- Dependencies: adds `zod` library.
- Systems: form validation state management and error display logic.
