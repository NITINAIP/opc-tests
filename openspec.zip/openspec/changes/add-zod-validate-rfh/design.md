## Context

The existing form infrastructure uses React Hook Form but validation is manual, inconsistent, and scattered across form pages. Each form implements its own validation logic, leading to code duplication and error handling inconsistency. Zod is a TypeScript-first schema validation library that integrates seamlessly with RHF via the resolver pattern.

## Goals / Non-Goals

**Goals:**
- Introduce Zod as the standard schema validation library for forms.
- Provide RHF resolver integration that automatically maps Zod schema validation results to RHF field errors.
- Enable developers to write type-safe, reusable form schemas.
- Simplify validation error handling and display across forms.

**Non-Goals:**
- Building a custom validation framework or replacing Zod.
- Migrating all existing forms in one release.
- Adding server-side validation integration (client-side only for now).

## Decisions

1. Use `zodResolver` from `@hookform/resolvers` for RHF integration.
- Rationale: Official resolver pattern; minimal boilerplate; best practices alignment with RHF.
- Alternative considered: custom resolver implementation. Rejected due to maintenance burden.

2. Create shared Zod schema utilities for common patterns (email, password, etc.).
- Rationale: Reduces duplication; easy to update validation rules globally.
- Alternative considered: inline schemas per form. Rejected due to inconsistency risk.

3. Export schemas with TypeScript type inference for form data.
- Rationale: Automatic type safety from schemas; reduces prop type duplication.
- Alternative considered: separate TS types and Zod schemas. Rejected due to maintenance burden.

## Risks / Trade-offs

- [Risk] Over-centralizing validation schemas could create bottlenecks for form-specific needs. → Mitigation: allow per-form schema extensions alongside shared schemas.
- [Risk] Tight coupling to Zod version could cause breakage on major updates. → Mitigation: use clear peer dependencies and test on updates.
- [Risk] Error message complexity could make form schema authoring harder. → Mitigation: provide examples and error message template helpers.
