## ADDED Requirements

### Requirement: Zod schema validation with RHF integration
The system SHALL provide Zod schema support integrated with React Hook Form via zodResolver, enabling schema-based form validation with automatic error mapping.

#### Scenario: Form validation uses Zod schema
- **WHEN** a developer defines a Zod schema and passes it to RHF via zodResolver
- **THEN** the form automatically validates against the schema on input change and submission, and displays validation errors without manual error handling code

### Requirement: Typed form data from schemas
Form schemas using Zod SHALL enable TypeScript type inference such that form data types are automatically inferred from the schema definition, eliminating separate type declarations.

#### Scenario: Form data type matches schema
- **WHEN** a developer uses `z.infer<typeof schema>` to derive form data types
- **THEN** the inferred type provides full type safety for form values and submission handlers

### Requirement: Shared Zod schema utilities
The system SHALL provide reusable Zod schema utilities for common validation patterns (email, password, required fields, custom error messages) to encourage schema reuse and consistency.

#### Scenario: Common validation patterns are shared
- **WHEN** a developer imports a shared email validation schema or password schema
- **THEN** the developer can compose and extend these schemas for multiple forms without duplicating validation logic

### Requirement: Error message mapping
Zod validation errors SHALL be automatically mapped to React Hook Form field error messages, with customizable error message formatting.

#### Scenario: Schema validation error displays correctly
- **WHEN** a form field fails Zod schema validation
- **THEN** the validation error message from the Zod schema is automatically displayed in the field's error state without custom error mapping code
