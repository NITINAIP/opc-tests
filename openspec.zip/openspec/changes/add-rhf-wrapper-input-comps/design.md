## Context

The MUI input components are now available and working, but integrating them with React Hook Form requires repetitive boilerplate in every form: wrapping inputs in Controller, mapping value/onChange, handling form state and validation errors. This change provides convenience wrappers that encapsulate this pattern.

## Goals / Non-Goals

**Goals:**
- Create RHF wrapper components that eliminate boilerplate Controller setup for each input type.
- Ensure automatic value binding, field registration, and error state management.
- Keep wrappers thin - they should primarily orchestrate MUI components with RHF Controller patterns.
- Support both simple and complex input types (autocomplete, date/time with controlled mode).

**Non-Goals:**
- Introducing custom validation logic (use form-level or field-level validation via react-hook-form).
- Building a form-builder UI or dynamic form generation system.
- Changing the MUI input component API or appearance.

## Decisions

1. Create thin wrapper components that wrap MUI inputs with RHF Controller.
- Rationale: Keeps wrappers focused and transparent; developers can still access underlying MUI and RHF functionality if needed.
- Alternative considered: building thick abstractions with custom validation. Rejected to maintain flexibility and clarity.

2. Use Controller as the primary integration point.
- Rationale: Controller provides the standard RHF pattern for controlled components; aligns with RHF best practices.
- Alternative considered: using register() directly. Rejected because MUI inputs like autocomplete need controlled mode.

3. Provide a unified RHF wrapper props interface extending base MUI field props.
- Rationale: Developers see a single consistent API across all wrapper types.
- Alternative considered: creating separate prop interfaces per wrapper. Rejected due to cognitive load and inconsistency.

## Risks / Trade-offs

- [Risk] Over-abstraction could hide RHF Controller details needed for advanced use cases. → Mitigation: document Controller usage pattern and expose underlying components if needed.
- [Risk] Tight coupling to both MUI and RHF versions could break on updates. → Mitigation: use peer dependencies and clear version constraints.
- [Risk] Developers may bypass wrappers and use raw MUI+RHF combinations. → Mitigation: document wrapper benefits and provide migration guidance.
