## ADDED Requirements

### Requirement: RHF wrappers for all MUI input types
The system SHALL provide React Hook Form wrapper components for text input, textarea, select, checkbox, radio group, switch, autocomplete, and date/time inputs, each wrapping the corresponding MUI input with automatic Controller-based value binding.

#### Scenario: Developer uses RHF wrapper in a form
- **WHEN** a developer imports an RHF wrapper component (e.g., RHFTextInput) and passes a react-hook-form control object
- **THEN** the component automatically binds value, onChange, onBlur to the form field without explicit Controller usage in the form code

### Requirement: Automatic value and error binding
Each RHF wrapper component SHALL automatically map form state (value, error, touched, disabled) to component props, and render validation errors consistently.

#### Scenario: Form field displays validation error
- **WHEN** the form field has a validation error from react-hook-form
- **THEN** the wrapper automatically displays the error message using the underlying MUI component's error styling and helper text

### Requirement: Support for controlled inputs with complex value types
RHF wrappers for controlled MUI inputs (autocomplete, date/time) SHALL properly handle typed values and onChange callbacks matching react-hook-form's field state contract.

#### Scenario: Autocomplete value is correctly bound in form
- **WHEN** a form using RHF autocomplete wrapper submits
- **THEN** the selected value matches the form's field value from react-hook-form, not MUI's internal state

### Requirement: Developer-friendly wrapper API
Each RHF wrapper component SHALL accept a minimal, intuitive props interface: control (from useForm()), name, label, options (where applicable), and optional validation/display props.

#### Scenario: Props are intuitive and discoverable
- **WHEN** a developer inspects an RHF wrapper component's TypeScript interface
- **THEN** the required props (control, name) and optional props are clearly documented and minimal
