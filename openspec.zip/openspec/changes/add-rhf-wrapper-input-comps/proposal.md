## Why

The MUI input components library lacks a standardized integration layer with React Hook Form, which requires repetitive Controller setup, custom error mapping, and value binding logic in every form using these inputs. Creating dedicated RHF wrappers will simplify form integration, reduce boilerplate, and ensure consistent validation/error display patterns across all input types.

## What Changes

- Introduce RHF wrapper components that encapsulate Controller logic and value/error binding for each MUI input type.
- Provide a unified props interface for RHF-controlled inputs, automatically mapping form state to component state.
- Standardize validation error display and field registration patterns.
- Enable seamless form integration without exposing complex Controller patterns to form developers.

## Capabilities

### New Capabilities
- `rhf-input-wrappers`: Provide React Hook Form-integrated wrapper components for all MUI input types with automatic value binding, error mapping, and field registration.

### Modified Capabilities
- None.

## Impact

- Affected code: form pages that use MUI inputs with react-hook-form, shared input component library.
- APIs: introduces RHF wrapper component interface as a convenience layer over raw MUI inputs + Controller.
- Dependencies: depends on `mui-input-components` capability and `react-hook-form`.
- Systems: form interaction behavior and validation state management.
